<?php
// +----------------------------------------------------------------------
// | 控制台配置
// +----------------------------------------------------------------------
return [
    // 指令定义
    'commands' => [
        'dmtask' => 'app\command\Dmtask',
        'opiptask' => 'app\command\Opiptask',
        'certtask' => 'app\command\Certtask',
        'reset' => 'app\command\Reset',
    ],
];
